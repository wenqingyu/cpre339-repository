
public class GenreVideoGame {

}
